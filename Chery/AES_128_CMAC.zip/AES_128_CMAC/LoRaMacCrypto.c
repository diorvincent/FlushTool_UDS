/*
 / _____)             _              | |
 ( (____  _____ ____ _| |_ _____  ____| |__
 \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 _____) ) ____| | | || |_| ____( (___| | | |
 (______/|_____)_|_|_| \__)_____)\____)_| |_|
 (C)2013 Semtech
 ___ _____ _   ___ _  _____ ___  ___  ___ ___
 / __|_   _/_\ / __| |/ / __/ _ \| _ \/ __| __|
 \__ \ | |/ _ \ (__| ' <| _| (_) |   / (__| _|
 |___/ |_/_/ \_\___|_|\_\_| \___/|_|_\\___|___|
 embedded.connectivity.solutions===============
 
 Description: LoRa MAC layer implementation
 
 License: Revised BSD License, see LICENSE.TXT file include in the project
 
 Maintainer: Miguel Luis ( Semtech ), Gregory Cristian ( Semtech ) and Daniel Jäckle ( STACKFORCE )
 */
#include "utilities.h"

#include "aes.h"
#include "cmac.h"

#include "LoRaMacCrypto.h"

/*!
 * CMAC computation context variable
 */
static AES_CMAC_CTX AesCmacCtx[1];

void AES_128_CMAC( const uint8_t *buffer, uint16_t size, const uint8_t *key, uint8_t *token )
{
    AES_CMAC_Init( AesCmacCtx );
    
    AES_CMAC_SetKey( AesCmacCtx, key );
    
    AES_CMAC_Update( AesCmacCtx, buffer, size & 0xFF );
    
    AES_CMAC_Final( token, AesCmacCtx );
}
